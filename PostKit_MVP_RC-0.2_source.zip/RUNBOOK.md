# PostKit MVP RC-0.2 Runbook

스냅샷: `PostKit MVP RC-0.2`

작성일: 2026-07-02

이 문서는 새 컴퓨터 또는 실행 가능한 Windows 환경에서 RC-0.2 소스 스냅샷을 처음 확인하기 위한 절차입니다. RC-0.2는 정적 코드 기준 스냅샷이며 npm install, typecheck, build, dev server, 브라우저 QA가 아직 완료되지 않았습니다.

## 1. 현재 상태

- `npm install`은 아직 완료되지 않았습니다.
- 현재 프로젝트에는 `node_modules`가 없습니다.
- `typecheck`, `build`, `dev server` 실행 검증은 아직 완료되지 않았습니다.
- `node_modules`가 없어서 현재 실행 검증은 실패했습니다.
- `/video-studio`는 구현됐지만 실제 브라우저 WebM 생성 QA는 아직 필요합니다.
- 실제 AI/API/결제/SNS/클라우드 연결은 없습니다.
- 외부 패키지를 추가하지 않았습니다.
- API 키, 토큰, 비밀번호, 시크릿을 추가하지 않았습니다.

## 2. Windows PowerShell 실행 순서

PowerShell 실행 정책 문제를 피하기 위해 `npm` 대신 `npm.cmd`를 우선 사용합니다.

```powershell
cd C:\Projects\PostKit
node -v
npm.cmd -v
npm.cmd install
npm.cmd run typecheck
npm.cmd run build
npm.cmd run dev
```

`npm.cmd run dev` 실행 후 터미널에 표시되는 로컬 URL을 브라우저에서 엽니다. 일반적으로 `http://localhost:3000`입니다.

## 3. 브라우저 QA 순서

아래 순서로 페이지를 확인합니다.

1. `/diagnostics`
2. `/demo`
3. `/create`
4. `/results`
5. `/studio`
6. `/video-studio`
7. `/export`
8. `/history`
9. `/calendar`
10. `/campaigns`
11. `/account`
12. `/privacy`
13. `/pricing`

## 4. Video Studio QA 중점

- MediaRecorder, canvas.captureStream, WebM mimeType 지원 여부가 `/diagnostics`에서 표시되는지 확인합니다.
- `/video-studio`에서 사진 여러 장 기반 9:16 미리보기와 WebM 생성이 동작하는지 확인합니다.
- WebM 미지원 브라우저에서 PNG 프레임 세트와 문구 TXT fallback이 표시되는지 확인합니다.
- Export Center, History, Calendar, Campaign 연결이 동작하는지 확인합니다.
- localStorage에 영상 Blob, 대용량 base64 영상, Object URL, 원본 사용자 이미지/영상이 장기 저장되지 않는지 확인합니다.

## 5. 금지 사항

- 실제 `.env` 또는 `.env.local`에 API 키, 토큰, 비밀번호, 시크릿을 넣지 않습니다.
- 실제 AI, 결제, 인증, SNS, 클라우드 서비스를 연결하지 않습니다.
- 사용자 이미지, 사용자 영상, 브라우저 프로필, localStorage 덤프를 소스 ZIP이나 저장소에 넣지 않습니다.
- `npm.cmd install`, typecheck, build, dev server, 브라우저 QA가 모두 끝나기 전에는 실행 검증 완료 또는 production-ready로 표현하지 않습니다.

## 6. 실패 기록 템플릿

- 실행 환경:
- Node 버전:
- npm 버전:
- 실행 명령:
- 터미널 오류:
- 브라우저 URL:
- 브라우저 콘솔 오류:
- 관련 라우트 또는 파일:
- 재현 순서:
- demo 데이터 사용 여부:
- localStorage 초기화 또는 import 여부:
