# PostKit MVP RC-0.2 Snapshot Info

스냅샷 이름: `PostKit MVP RC-0.2`

스냅샷 정리일: 2026-07-02

스냅샷 성격: 정적 코드 기준 소스 스냅샷

이 스냅샷은 정적 코드 검토 기준이며 npm install, typecheck, build, dev server, 브라우저 QA가 아직 완료되지 않았습니다.

## RC-0.1 대비 변경점

- RC-0.1 전체 기능을 유지했습니다.
- `/video-studio` 릴스·쇼츠 영상 제작 v1이 포함되었습니다.
- 브라우저 Canvas + MediaRecorder + canvas.captureStream 기반 WebM 생성 구조가 포함되었습니다.
- MediaRecorder/canvas.captureStream/WebM 지원 여부를 진단하는 항목이 포함되었습니다.
- Video Studio에서 Export, History, Calendar, Campaign, Demo, Diagnostics 흐름으로 연결되는 구조가 포함되었습니다.
- 영상 프로젝트 설정은 localStorage에 저장하되 영상 Blob, 대용량 base64 영상, Object URL, 원본 사용자 이미지/영상의 장기 저장은 금지하는 정책을 문서화했습니다.
- 이번 RC-0.2 정리 작업에서는 새 기능, 가격 정책, 크레딧 정책, 개인정보 정책, 실제 외부 연동을 추가하거나 변경하지 않았습니다.

## 추가된 라우트

- `/video-studio`

## 추가된 주요 파일

- `app/video-studio/page.tsx`
- `lib/video/videoPresets.ts`
- `lib/video/videoTemplates.ts`
- `lib/video/videoRenderer.ts`
- `lib/video/videoStorage.ts`
- `lib/video/videoSessionStore.ts`
- `lib/video/videoUtils.ts`
- `lib/diagnostics/videoChecks.ts`

## 추가된 localStorage 키

- `postkit-video-projects`: Video Studio 프로젝트 설정 저장
- `postkit-video-preferences`: 마지막 영상 템플릿, 플랫폼, 길이, 전환 선호 저장

localStorage에는 영상 Blob, 대용량 base64 영상, Object URL, 원본 사용자 이미지/영상 파일을 장기 저장하지 않습니다.

## 실행 검증 여부

미완료입니다.

- `npm install`은 아직 완료되지 않았습니다.
- `npm.cmd run typecheck`는 `node_modules` 부재로 `tsc`를 찾지 못해 완료되지 않았습니다.
- `npm.cmd run build`는 `node_modules` 부재로 `next`를 찾지 못해 완료되지 않았습니다.
- `npm.cmd run dev`와 dev server 확인은 아직 완료되지 않았습니다.
- 브라우저 QA는 아직 완료되지 않았습니다.
- `/video-studio` 실제 브라우저 WebM 생성 QA는 아직 필요합니다.

## 외부 연동 여부

- 외부 API 연결 여부: 없음
- 실제 AI API 연결 여부: 없음
- 실제 영상 생성 API 연결 여부: 없음
- 실제 결제 API 연결 여부: 없음
- 실제 SNS 자동 게시 API 연결 여부: 없음
- 실제 클라우드 DB 또는 object storage 연결 여부: 없음

## 패키지와 시크릿

- 외부 패키지 추가 여부: 없음
- API 키/시크릿 포함 여부: 없음
- API 키/토큰/비밀번호 추가 여부: 없음
- `.env.local` 포함 여부: 없음
- 실제 `.env` 포함 여부: 없음
- `package-lock.json`: 현재 없음. RC-0.2 정리 과정에서 생성하지 않았습니다.

## 알려진 제한사항

- 이 스냅샷은 정적 코드 기준이며 실행 성공을 보장하지 않습니다.
- `node_modules`가 없어 현재 실행 검증은 실패했습니다.
- Next.js, React, TypeScript 조합은 새 환경에서 설치 후 확인해야 합니다.
- Video Studio WebM 생성, fallback, Blob URL 정리, Export/History/Calendar/Campaign 연결은 실제 브라우저 QA가 필요합니다.
- 모든 AI, 결제, 인증, SNS 게시, 클라우드 저장은 mock 또는 placeholder 상태입니다.
- 개인정보 처리방침, 이용약관, 광고·협찬 표시 문구는 실제 출시 전 법률 검토가 필요합니다.

## 다음 실행 명령

Windows PowerShell 기준입니다. 실행 정책 문제를 피하기 위해 `npm` 대신 `npm.cmd`를 우선 사용합니다.

```powershell
cd C:\Projects\PostKit
node -v
npm.cmd -v
npm.cmd install
npm.cmd run typecheck
npm.cmd run build
npm.cmd run dev
```

## 브라우저 QA 순서

1. `/diagnostics`
2. `/demo`
3. `/create`
4. `/results`
5. `/studio`
6. `/video-studio`
7. `/export`
8. `/history`
9. `/calendar`
10. `/campaigns`
11. `/account`
12. `/privacy`
13. `/pricing`
