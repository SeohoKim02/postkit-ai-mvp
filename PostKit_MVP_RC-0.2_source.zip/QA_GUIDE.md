# PostKit QA Guide

이 문서는 PostKit을 실제 실행 가능한 환경에서 빠르게 확인하기 위한 QA 순서입니다. 현재 프로젝트는 실제 AI API, 결제, 인증, SNS 자동 게시, 클라우드 저장을 연결하지 않은 mock/localStorage 기반입니다.

## RC-0.2 QA 전제

`PostKit MVP RC-0.2`는 정적 코드 기준 스냅샷입니다.

- `npm install`은 아직 완료되지 않았습니다.
- `typecheck`, `build`, `dev server` 실행 검증은 아직 완료되지 않았습니다.
- 현재 환경에는 `node_modules`가 없어 실행 검증이 실패했습니다.
- `/video-studio`는 구현됐지만 실제 브라우저 WebM 생성 QA는 아직 필요합니다.
- 다음 단계는 새 컴퓨터 또는 실행 가능한 환경에서 `npm.cmd install`부터 시작하는 것입니다.

## 1. 실행 준비

1. Node.js와 npm이 PATH에 잡혀 있는지 확인합니다.
2. 의존성을 설치합니다.

```powershell
npm.cmd install
```

3. 타입과 빌드를 확인합니다.

```powershell
npm.cmd run typecheck
npm.cmd run build
```

4. 개발 서버를 실행합니다.

```powershell
npm.cmd run dev
```

5. 브라우저에서 `http://localhost:3000`을 엽니다.

Windows PowerShell에서는 실행 정책 문제를 피하기 위해 `npm` 대신 `npm.cmd`를 우선 사용합니다.

## 1-1. RC-0.2 브라우저 QA 순서

1. `/diagnostics`
2. `/demo`
3. `/create`
4. `/results`
5. `/studio`
6. `/video-studio`
7. `/export`
8. `/history`
9. `/calendar`
10. `/campaigns`
11. `/account`
12. `/privacy`
13. `/pricing`

## 2. 데모 데이터 생성

1. `/diagnostics`로 이동합니다.
2. 기존 데이터가 있다면 먼저 Account 데이터 내보내기 또는 진단센터 백업을 내려받습니다.
3. `데모 추가`를 눌러 기존 데이터를 유지한 상태로 샘플 데이터를 추가합니다.
4. 전체 교체가 필요하면 `백업 후 교체`를 누릅니다. 이 경우 먼저 백업 JSON이 다운로드됩니다.
5. 데모 데이터는 `demo: true` 또는 `source: "demo"` 표시가 있는 항목으로 저장됩니다.
6. 삭제 테스트는 `데모만 삭제`를 사용합니다. 실제 사용자 데이터가 함께 삭제되지 않는지 확인합니다.

## 3. 전체 진단 실행

1. `/diagnostics` 진입 시 가벼운 진단이 자동 실행되는지 확인합니다.
2. `전체 진단 실행`을 눌러 localStorage 참조와 무결성 검사를 수행합니다.
3. 다음 상태가 텍스트와 배지로 표시되는지 확인합니다.
   - 정상
   - 확인 필요
   - 오류
   - 미지원
   - 미구현
   - 실행 전
4. 카메라, 마이크, 알림 권한 프롬프트가 자동으로 뜨지 않는지 확인합니다.
5. 진단 보고서를 JSON과 TXT로 다운로드합니다.
6. 보고서에 캡션 원문, 이미지, 이메일, API 키, 토큰, 결제정보, 전체 localStorage 원문이 포함되지 않는지 확인합니다.

## 4. 필수 사용자 흐름

1. Landing에서 시작 버튼 이동
2. Dashboard 표시
3. 온보딩 완료
4. Create 입력
5. 업로드 권리 확인
6. 크레딧 차감
7. Results 생성
8. 캡션 선택
9. 복사
10. 좋아요·별로예요
11. 수정 저장
12. 개인화 반영
13. Studio 열기
14. 템플릿 변경
15. PNG 생성
16. Video Studio 열기
17. 사진 여러 장 선택
18. 영상 미리보기 재생/일시정지
19. WebM 생성 또는 PNG/TXT fallback 확인
20. 다운로드
21. SNS 공유 fallback
22. Export 기록
23. History 확인
24. Calendar 연결
25. Campaign 연결
26. Pricing mock 플랜 변경
27. mock 크레딧 구매
28. Account 데이터 내보내기
29. Privacy 데이터 삭제
30. 게스트 초기화

## 5. Video Studio v1 QA

1. Results 또는 History에서 `영상 만들기`/`영상 다시 열기`를 눌러 `/video-studio`로 이동합니다.
2. Instagram Reels, Instagram Story, TikTok, YouTube Shorts 프리셋이 모두 1080×1920, 9:16으로 표시되는지 확인합니다.
3. 사진 여러 장을 업로드하고, 파일명과 세션 연결 상태가 보이는지 확인합니다.
4. 5초, 8초, 10초, 15초만 선택 가능하고 15초 초과 입력 경로가 없는지 확인합니다.
5. 전환 효과 없음, 페이드, 슬라이드 업, 슬라이드 좌우, 천천히 확대, 줌 인/아웃을 바꾸며 미리보기를 확인합니다.
6. 제목, 후킹 문구, 제품명, CTA, 브랜드명, 광고·협찬 문구, 할인코드가 Canvas 밖으로 나가지 않는지 확인합니다.
7. 재생, 일시정지, 처음으로 버튼이 동작하고 unmount 후 미리보기 루프가 멈추는지 확인합니다.
8. 지원 브라우저에서는 WebM 생성 후 미리보기 video, 다운로드, Web Share 또는 fallback이 동작하는지 확인합니다.
9. 미지원 브라우저에서는 앱 오류 대신 PNG 프레임 세트와 문구 TXT 다운로드가 안내되는지 확인합니다.
10. Export Center에서 세션 WebM Blob이 있으면 영상 미리보기/다운로드/공유가 보이고, Blob이 없으면 Video Studio 재생성 안내가 보이는지 확인합니다.
11. History에서 Video Studio 배지, 영상 다시 열기, 영상 복제, 영상 WebM, 영상 내보내기 버튼을 확인합니다.
12. Calendar와 Campaign에서 Reels/TikTok/Shorts/Story 계열 항목에 Video Studio 진입이 보이는지 확인합니다.
13. localStorage에 영상 Blob, base64 영상, Object URL, 원본 이미지 전체가 저장되지 않는지 확인합니다.
14. 영상 편집, 다운로드, Export 연결, SNS 공유 준비 후 크레딧 잔액이 변하지 않는지 확인합니다.

체크 상태는 `/diagnostics`의 QA 체크리스트에 저장됩니다.

## 6. 크레딧 테스트

1. `/pricing`에서 현재 플랜과 잔액을 확인합니다.
2. mock 플랜 변경 모달을 확인합니다.
3. mock 추가 크레딧 구매를 실행합니다.
4. `/create`에서 업로드 패키지 생성 시 30 크레딧 차감이 표시되는지 확인합니다.
5. 잔액이 부족한 상태에서는 생성이 시작되지 않는지 확인합니다.
6. 실패 mock 흐름이 발생하면 동일 debit에 환불이 1회만 연결되는지 확인합니다.
7. `/diagnostics`에서 크레딧 총액, 원장, 중복 debit/refund 경고를 확인합니다.

## 7. Studio 테스트

1. `/results`에서 Studio로 이동합니다.
2. 플랫폼, 출력 크기, 템플릿을 바꿉니다.
3. 텍스트 위치, 글자 크기, 오버레이, 브랜드 색상을 조정합니다.
4. PNG 생성과 다운로드가 동작하는지 확인합니다.
5. 새로고침 뒤 원본 이미지가 없을 경우 fallback이 안전하게 표시되는지 확인합니다.
6. `/diagnostics`에서 Canvas, toBlob, templateId, outputPresetId, width/height, zoom, position 경고가 없는지 확인합니다.

## 8. 다운로드와 Web Share fallback

1. `/export`에서 개별 TXT/JSON/PNG 다운로드를 확인합니다.
2. 전체 다운로드가 순차 다운로드 방식으로 동작하는지 확인합니다.
3. 모바일 브라우저에서 Web Share가 지원되면 공유창이 열리는지 확인합니다.
4. Web Share가 미지원이면 다운로드, 전체 문구 복사, 플랫폼 열기 fallback이 표시되는지 확인합니다.
5. 다운로드와 공유에는 크레딧이 차감되지 않는지 확인합니다.

## 9. 개인정보 삭제 테스트

1. `/privacy`에서 개인정보 설정을 저장합니다.
2. 데이터 내보내기를 실행합니다.
3. 업로드 파일, 생성 결과, History, 개인화, 내보내기 기록, 캠페인/일정 삭제 흐름을 확인합니다.
4. 전체 계정 데이터 삭제 전 확인 절차와 백업 안내가 표시되는지 확인합니다.
5. 감사 로그에는 원문 캡션이나 이미지 데이터가 저장되지 않는지 확인합니다.

## 10. Account export/import 테스트

1. `/account`에서 JSON 내보내기를 실행합니다.
2. 내보낸 JSON에 비밀번호, 인증 토큰, API 키, 결제 카드 정보, 이미지 Blob이 없는지 확인합니다.
3. JSON 가져오기에서 병합과 백업 후 교체를 각각 확인합니다.
4. 잘못된 JSON, 큰 JSON, secret-like 문자열이 들어간 JSON이 차단되는지 확인합니다.
5. mock 계정 전환, 게스트 전환, 워크스페이스 멤버 역할 변경이 브라우저 내부에서만 동작하는지 확인합니다.

## 11. 오류 기록 방법

오류를 발견하면 아래 항목을 기록합니다.

- 페이지 경로
- 재현 순서
- 기대 결과
- 실제 결과
- 브라우저와 OS
- 진단 보고서 JSON
- localStorage 백업 JSON 필요 여부

민감한 캡션 원문, 이미지, 이메일, API 키, 토큰, 결제정보는 이슈 본문에 붙이지 않습니다.

## 12. 실제 출시 전 필수 QA

- 서버 기반 인증과 권한 검증
- 서버 기반 크레딧 원장 트랜잭션
- 실제 결제 웹훅 재처리와 중복 지급 방지
- 실제 AI provider rate limit과 비용 모니터링
- 이미지/영상 저장소 보안
- 개인정보 처리방침과 이용약관 법률 검토
- 광고·협찬 표시 안내 법률 검토
- SNS OAuth 토큰 암호화와 게시 실패 재시도
- 관리자 신고/차단/삭제 처리 도구

## 13. RC-0.2 Snapshot Handoff

The current source snapshot is `PostKit MVP RC-0.2`, dated 2026-07-02.

Before QA on a new machine:

1. Read [SNAPSHOT_INFO.md](./SNAPSHOT_INFO.md).
2. Read [RUNBOOK.md](./RUNBOOK.md).
3. Confirm Node.js and npm are available.
4. Run `npm.cmd install`.
5. Run `npm.cmd run typecheck`.
6. Run `npm.cmd run build`.
7. Run `npm.cmd run dev`.
8. Open `/diagnostics`.
9. Create demo data only if needed.
10. Run full diagnostics and record the report.

Do not mark this snapshot as runtime-verified until those commands and the browser QA pass.
